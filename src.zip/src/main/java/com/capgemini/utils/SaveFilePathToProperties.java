package com.capgemini.utils;

import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Properties;

public class SaveFilePathToProperties {

	public static void main(String[] args) {
		SaveFilePathToProperties.saveFilePath("xyz/path");
	}

	public static void saveFilePath(final String filePath) {
		// Instantiating the properties file
		Properties props = new Properties();
		// Populating the properties file
		props.put("FilePath", filePath);
		// Instantiating the FileInputStream for output file
		String path = "C:\\Users\\abhandeg\\Downloads\\NavikaranFiles\\NavikaranFiles.properties";
		FileOutputStream outputStrem;
		try {
			outputStrem = new FileOutputStream(path);
			props.store(outputStrem, "This is a sample properties file");
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		System.out.println("Properties file created......");
	}

}
