package com.capgemini.utils;

import java.io.File;
import java.io.FileNotFoundException;

import org.springframework.util.ResourceUtils;

public class ResourceFileLoader {

	public static File getResourceFile(final String fileName) {

		File file = null;
		try {
			file = ResourceUtils.getFile("classpath:" + fileName);
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		}
		return file;
	}

}
